package exercises;
import java.util.Arrays;
import java.util.Scanner;

public class JaBa {
	public static void AssignArray(double[] arr, Scanner in) {
		
		for(int i =0;i<arr.length;i++) {

			System.out.print("Enter element "+i+" :");
			
			arr[i]=in.nextDouble();
			
		}
	}
	public static void printArray(double[] arr) {
		System.out.print(Arrays.toString(arr));
	}
	public static double[] decimals(double[] a) {
		int counter=0;
		for(double ele : a) {
			if(ele%1<0.5) {
				counter++;
			}
		}
	double[] deci = new double[counter];
	int i=0;
	for(double ele : a) {
		if(ele%1<0.5) {
			deci[i]=ele;
			i++;
		}
	}
	return deci;
	}
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter length of array :");
		int length=in.nextInt();
		double[] arr=new double[length];
		AssignArray(arr, in);
		printArray(arr);
		double[] res=decimals(arr);
		printArray(res);
		in.close();
	}	
}
