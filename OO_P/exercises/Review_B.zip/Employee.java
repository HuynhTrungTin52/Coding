package exercises;

public class Employee {
	private String id;
	private double[] salaries;
	public Employee(String id, double[] salaries) {
		this.id=id;
		this.salaries=salaries;
	}
	public double getAverageSalary() {
		double avg=0;
		for(double ele : salaries) {
			avg+=ele;
		}
	return avg/salaries.length;
	}

	public String getCategory() {
		double sal=getAverageSalary();
		if(sal>=20000) return "High Income";
		if(sal>=15000) return "Middle Income";
		if(sal>=10000) return "Low Income";
		return "Below Poverty Line";
	}
	public static void main(String[] args) {
		double[] sal = {50000,10000,10000};
		Employee mike = new Employee("1234", sal);
		System.out.println(mike.getAverageSalary());
		System.out.print(mike.getCategory());
	}
}
