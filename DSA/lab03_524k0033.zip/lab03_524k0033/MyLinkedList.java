import java.util.NoSuchElementException;

public class MyLinkedList<E> implements ListInterface<E> {
    private Node<E> head;
    private int numNode;

    public MyLinkedList() {
        head = null;
        numNode = 0;
    }

    @Override
    public void addFirst(E item) {
        head = new Node<E>(item, head);
        numNode++;
    }

    @Override
    public void addAfter(Node<E> curr, E item) {
        if (curr == null) {
            addFirst(item);
        } else {
            Node<E> newNode = new Node<E>(item, curr.getNext());
            curr.setNext(newNode);
            numNode++;
        }
    }

    @Override
    public void addLast(E item) {
        if (head == null) {
            addFirst(item);
        } else {
            Node<E> tmp = head;
            while (tmp.getNext() != null) {
                tmp = tmp.getNext();
            }
            Node<E> newNode = new Node<E>(item, null);
            tmp.setNext(newNode);
            numNode++;
        }
    }

    @Override
    public E removeFirst() throws NoSuchElementException {
        if (head == null) {
            throw new NoSuchElementException("Can't remove element from an empty list");
        } else {
            Node<E> tmp = head;
            head = head.getNext();
            numNode--;
            return tmp.getData();
        }
    }

    @Override
    public E removeAfter(Node<E> curr) throws NoSuchElementException {
        if (curr == null) {
            throw new NoSuchElementException("Can't remove element from an empty list");
        } else {
            Node<E> delNode = curr.getNext();
            if (delNode != null) {
                curr.setNext(delNode.getNext());
                numNode--;
                return delNode.getData();
            } else {
                throw new NoSuchElementException("No next node to remove");
            }
        }
    }

    @Override
    public E removeLast() throws NoSuchElementException {
        if (head == null) {
            throw new NoSuchElementException("Can't remove element from an empty list");
        } else {
            Node<E> preNode = null;
            Node<E> delNode = head;
            if (delNode.getNext() == null) {
                return removeFirst();
            }
            while (delNode.getNext() != null) {
                preNode = delNode;
                delNode = delNode.getNext();
            }
            preNode.setNext(delNode.getNext());
            numNode--;
            return delNode.getData();
        }
    }

    @Override
    public E removeCurr(Node<E> Curr) throws NoSuchElementException {
        if (Curr == null) {
            throw new NoSuchElementException("Can't remove element from an empty list");
        } else {
            Node<E> pre = null, del = head;
            while (del != Curr) {
                pre = del;
                del.getNext();
            }
            return removeAfter(pre);
        }
    }

    @Override
    public void print() {
        if (head != null) {
            Node<E> tmp = head;
            System.out.print("List: " + tmp.getData());
            tmp = tmp.getNext();
            while (tmp != null) {
                System.out.print(" -> " + tmp.getData());
                tmp = tmp.getNext();
            }
            System.out.println();
        } else {
            System.out.println("List is empty!");
        }
    }

    @Override
    public boolean isEmpty() {
        if (numNode == 0)
            return true;
        return false;
    }

    @Override
    public E getFirst() throws NoSuchElementException {
        if (head == null) {
            throw new NoSuchElementException("Can't get element from an empty list");
        } else {
            return head.getData();
        }
    }

    @Override
    public Node<E> getHead() {
        return head;
    }

    public Node<E> setHead(Node<E> newHead) {
        Node<E> delNode = this.head;
        this.head = newHead;
        return delNode;
    }

    @Override
    public int size() {
        return numNode;
    }

    @Override
    public boolean contains(E item) {
        Node<E> tmp = head;
        while (tmp != null) {
            if (tmp.getData().equals(item))
                return true;
            tmp = tmp.getNext();
        }
        return false;
    }


    //FOR INT USES ONLY
    @Override
    public void addSortedList(E item) {
        Node<E> newNode = new Node<>(item);
        if (head == null || (int)newNode.getData() < 0) {
            newNode.setNext(head);
            head = newNode;
            return;
        }

        addSortedListRecursive(head, newNode);
    }

    private void addSortedListRecursive(Node<E> curr, Node<E> next) {

        if (curr.getNext() == null) {
            curr.setNext(next);
            return;
        }
        if ((int) next.getData() < (int)curr.getNext().getData()) {
            next.setNext(curr.getNext());
            curr.setNext(next);
            return;
        }
        addSortedListRecursive(curr.getNext(), next);
    }

    @Override
    public int countEven() {
    return countEvenRecursive(head);
}

private int countEvenRecursive(Node<E> head2) {

    if (head2 == null) {
        return 0;
    }
    int countForCurrent = ((int)head2.getData() % 2 == 0) ? 1 : 0;

    return countForCurrent + countEvenRecursive(head2.getNext());
}

@Override
public int sumAll() {
    return sumAllRecursive(head);
}

private int sumAllRecursive(Node<E> current) {
 
    if (current == null) {
        return 0;
    }

    return (int)current.getData() + sumAllRecursive(current.getNext());
}
}