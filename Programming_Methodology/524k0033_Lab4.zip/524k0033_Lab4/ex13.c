#include <stdio.h>

void separateOddEven(int *arr, int size, int *oddArr, int *evenArr) {
    int oddIndex = 0, evenIndex = 0;

    for (int i = 0; i < size; i++) {
        if (arr[i] % 2 == 0) {
            evenArr[evenIndex] = arr[i];
            evenIndex++;
        } else {
            oddArr[oddIndex] = arr[i];
            oddIndex++;
        }
    }
}

int main() {
    int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int size = sizeof(arr) / sizeof(arr[0]);
    int oddArr[size], evenArr[size];

    separateOddEven(arr, size, oddArr, evenArr);

    printf("Odd numbers: ");
    for (int i = 0; i < size/2; i++) {
        if (oddArr[i] != 0) {
            printf("%d ", oddArr[i]);
        }
    }
    printf("\n");

    printf("Even numbers: ");
    for (int i = 0; i < size/2; i++) {
        if (evenArr[i] != 0) {
            printf("%d ", evenArr[i]);
        }
    }
    printf("\n");

    return 0;
}